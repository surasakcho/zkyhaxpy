# setup.py
import setuptools 

setuptools.setup(
   name='zkyhaxpy',  
   version='0.2.1',
   packages=setuptools.find_packages(),
   description="A python package for personal utilities",
   url="https://github.com/surasakcho/zkyhaxpy",
   author="Surasak Choedpasuporn",
   author_email="surasak.cho@gmail.com",
)
