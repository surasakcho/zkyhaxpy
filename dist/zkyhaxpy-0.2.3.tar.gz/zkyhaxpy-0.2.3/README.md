This is zkyhax-py package.
zkyhax-py is a python package for personal usage.
It provides a lot of useful tools for working as data scientist.