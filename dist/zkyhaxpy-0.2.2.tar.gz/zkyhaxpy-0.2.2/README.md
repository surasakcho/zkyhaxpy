This is zkyhaxpy package.
zkyhax is a python package for personal usage.
It provides a lot of useful tools for working as data scientist.